'use strict';

module.exports = require('./async').eachOfLimit;
